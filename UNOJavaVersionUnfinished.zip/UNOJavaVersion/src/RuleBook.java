public class RuleBook {

    public static void printRules(){
        System.out.println("This is my version of UNO. Only playing with number doubles and you can put a draw 4 on a draw 2 :| ");
        System.out.println("To play a card simply type in the color and the number");
    }
}
