public class Players {
    private String name;
    private int playerOrder;

    public Players(String name, int playerOrder){
        this.name = name;
        this.playerOrder = playerOrder;

    }

    public String showMyCards(){
        return "Your cards are: ";
    }

    public String toString(){

        return name + ", it is your turn.";
    }
}
