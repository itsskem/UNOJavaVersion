import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class PlayingTable {
    //all the arrays
    public static ArrayList<Players> playerNames = new ArrayList<Players>(); //array for players in game
    private static ArrayList<String> deck = new ArrayList<String>(); //array for the deck
    private static ArrayList<Integer> numberDeck = new ArrayList<Integer>(); //makes a new arraylist for cards into numbers for distribution
    private static ArrayList<Integer> playerCards = new ArrayList<Integer>(); //makes a deck of cards for the player
    public static ArrayList<ArrayList<Integer>> playerStack = new ArrayList<>();  //creating the stack of layers
    private static ArrayList<String> deckForPlay = new ArrayList<String>(); //makes the deck of cards for the playing table


    public static void main(String[] args) {
        //TO-DO list
        //make each player a object using an if statement **
        //make each card a number; math.random = each object has seven cards
        //make a pile and a big pile stack. remove last card of arraylist to other arraylist and show the next up
        //moves = a method. if statement ~ that method

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        //introduction
        System.out.println("Welcome to the online Java version of UNO!");
        System.out.println("If you would like to play, say 'PLAY'. If you would like to see the rules, say 'RULES'");

        RuleBook theRules = null;
        String userOption = input.nextLine();

        //prints the rules of the game
        if (userOption.equals("RULES")) {
            RuleBook.printRules();
        }


        //starts the game
        if (userOption.equals("PLAY")) {

        System.out.println("Bet, lets play.");

            //creating a deck of cards
            System.out.println("Please be patient while the deck initializes...");
            deck.add("red1");
            deck.add("red2");
            deck.add("red3");
            deck.add("red4");
            deck.add("red5");
            deck.add("red6");
            deck.add("red7");
            deck.add("red8");
            deck.add("red9");
            deck.add("green1");
            deck.add("green2");
            deck.add("green3");
            deck.add("green4");
            deck.add("green5");
            deck.add("green6");
            deck.add("green7");
            deck.add("green8");
            deck.add("green9");
            deck.add("blue1");
            deck.add("blue2");
            deck.add("blue3");
            deck.add("blue4");
            deck.add("blue5");
            deck.add("blue6");
            deck.add("blue7");
            deck.add("blue8");
            deck.add("blue9");
            deck.add("yellow1");
            deck.add("yellow2");
            deck.add("yellow3");
            deck.add("yellow4");
            deck.add("yellow5");
            deck.add("yellow6");
            deck.add("yellow7");
            deck.add("yellow8");
            deck.add("yellow9");
            deck.add("redSkip");
            deck.add("blueSkip");
            deck.add("greenSkip");
            deck.add("yellowSkip");
            deck.add("redSkip");
            deck.add("yellowAddTwo");
            deck.add("greenAddTwo");
            deck.add("redAddTwo");
            deck.add("blueAddTwo");
            deck.add("Draw4One");
            deck.add("Draw4Two");
            deck.add("Draw4Three");
            deck.add("Draw4Four");
            deck.add("wildOne");
            deck.add("wildTwo");
            deck.add("wildThree");
            deck.add("wildFour");

            int deckSize = deck.size(); //to access deck size

            deckForPlay.add("red1");
            deckForPlay.add("red2");
            deckForPlay.add("red3");
            deckForPlay.add("red4");
            deckForPlay.add("red5");
            deckForPlay.add("red6");
            deckForPlay.add("red7");
            deckForPlay.add("red8");
            deckForPlay.add("red9");
            deckForPlay.add("green1");
            deckForPlay.add("green2");
            deckForPlay.add("green3");
            deckForPlay.add("green4");
            deckForPlay.add("green5");
            deckForPlay.add("green6");
            deckForPlay.add("green7");
            deckForPlay.add("green8");
            deckForPlay.add("green9");
            deckForPlay.add("blue1");
            deckForPlay.add("blue2");
            deckForPlay.add("blue3");
            deckForPlay.add("blue4");
            deckForPlay.add("blue5");
            deckForPlay.add("blue6");
            deckForPlay.add("blue7");
            deckForPlay.add("blue8");
            deckForPlay.add("blue9");
            deckForPlay.add("yellow1");
            deckForPlay.add("yellow2");
            deckForPlay.add("yellow3");
            deckForPlay.add("yellow4");
            deckForPlay.add("yellow5");
            deckForPlay.add("yellow6");
            deckForPlay.add("yellow7");
            deckForPlay.add("yellow8");
            deckForPlay.add("yellow9");
            deckForPlay.add("redSkip");
            deckForPlay.add("blueSkip");
            deckForPlay.add("greenSkip");
            deckForPlay.add("yellowSkip");
            deckForPlay.add("redSkip");
            deckForPlay.add("yellowAddTwo");
            deckForPlay.add("greenAddTwo");
            deckForPlay.add("redAddTwo");
            deckForPlay.add("blueAddTwo");
            deckForPlay.add("Draw4One");
            deckForPlay.add("Draw4Two");
            deckForPlay.add("Draw4Three");
            deckForPlay.add("Draw4Four");
            deckForPlay.add("wildOne");
            deckForPlay.add("wildTwo");
            deckForPlay.add("wildThree");
            deckForPlay.add("wildFour");



            for(int i = 1; i <= deckSize; i++){  //converts each card into a number and adds into the arraylist
                int cardAsNumber = i;
                cardAsNumber = Integer.parseInt(deck.get(i));
               numberDeck.add(cardAsNumber);

            }
            Collections.shuffle(numberDeck); //shuffles the deck
            System.out.println("Deck is initialized and shuffled.");

            //adding players to the game

            System.out.println("How many players are playing?");
            int numOfPlayers = input.nextInt(); //user enters number of players

            System.out.println("How many cards does each player get?");
            int amountOfCards = input.nextInt(); //user enters number of cards




            for(int i = 1; i <= numOfPlayers; i++){
                System.out.println("Enter player name: ");
                String name = input.nextLine();
                System.out.println("What is this player's number?");
                int playerNum = input.nextInt();
                int k = 0; //a controlling variable for the while loop
                while (k <= i) {
                    playerNames.add(new Players(name, playerNum));
                    k++;
                   /* for(int c =1 ;i<4;i++)
                    {
                        int [] cardSet = new int[7];
                    }
                } */


                    for (int I = 0; I < numOfPlayers; I++) {
                        ArrayList<Integer> playersCards = new ArrayList<>();
                        for(int b = 0; b < amountOfCards; b++){
                            for (int a = 0; i < deckSize; i++)
                            {
                                int index = (int)(Math.random() * deckSize);
                                playerCards.add(index);

                            }
                        }
                    }

                        playerStack.add(playerCards);
                    }
            }

            System.out.println("Time to play!");

            for (int k = 1; k <= numOfPlayers; k++) {
                System.out.println("It is Player " + k + "'s turn.");
                System.out.println("What would you like to do?");
                System.out.println("")
                String playerAnswer = input.nextLine();
                if (playerAnswer.equals("show")) {
                    System.out.println("wombats rock");
                } else {
                    System.out.println("oh");
                }
            }











          /*  boolean quit = false;
            while (quit){
                String playerChoice = input.nextLine();
                if (playerChoice.equals("quit")){
                    System.out.println("Okay. Thanks for playing");
                    break;
                }
                if(playerChoice.equals("go")){ */

        }
    }
}





















